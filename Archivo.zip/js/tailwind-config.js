tailwind.config = {
	theme: {
		extend: {
			colors: {
				brand: "#233A59",
				primary: "#0A7ABF",
				secondary: "#068BBF",
				aux: "#F2B705",
				auxDark: "#F2A71B",
			},
			fontFamily: {
				miFuente: ["MiFuentePersonalizada", "sans-serif"], // Asegúrate de haber definido tu fuente personalizada en tu CSS
			},
			fontWeight: {
				normal: "400",
				bold: "700",
				// Aquí puedes agregar más pesos personalizados si tu fuente los soporta
			},
			fontSize: {
				xs: [
					"0.75rem",
					{
						lineHeight: "1.5rem",
					},
				],
				1: [
					"0.75rem",
					{
						lineHeight: "1.5rem",
					},
				],
				sm: [
					"0.875rem",
					{
						lineHeight: "1.5rem",
					},
				],
				2: [
					"0.875rem",
					{
						lineHeight: "1.5rem",
					},
				],
				base: [
					"1rem",
					{
						lineHeight: "1.5rem",
					},
				],
				3: [
					"1rem",
					{
						lineHeight: "1.5rem",
					},
				],
				lg: [
					"1.25rem",
					{
						lineHeight: "1.5rem",
					},
				],
				4: [
					"1.25rem",
					{
						lineHeight: "1.5rem",
					},
				],
				xl: [
					"1.5rem",
					{
						lineHeight: "2rem",
					},
				],
				5: [
					"1.5rem",
					{
						lineHeight: "2rem",
					},
				],
				"2xl": [
					"1.625rem",
					{
						lineHeight: "2rem",
					},
				],
				6: [
					"1.625rem",
					{
						lineHeight: "2rem",
					},
				],
				"3xl": [
					"2rem",
					{
						lineHeight: "2.5rem",
					},
				],
				7: [
					"2rem",
					{
						lineHeight: "2.5rem",
					},
				],
				"4xl": [
					"2.5rem",
					{
						lineHeight: "3rem",
					},
				],
				8: [
					"2.5rem",
					{
						lineHeight: "3rem",
					},
				],
			},
			fontWeight: {
				thin: "100",
				extralight: "200",
				light: "300",
				normal: "400",
				medium: "500",
				semibold: "600",
				bold: "700",
				extrabold: "800",
				black: "900",
				100: "100",
				200: "200",
				300: "300",
				400: "400",
				500: "500",
				600: "600",
				700: "700",
				800: "800",
				900: "900",
			},
			lineHeight: {
				none: "1",
				tight: "1.25",
				snug: "1.375",
				normal: "1.5",
				relaxed: "1.625",
				loose: "2",
				1: "1rem",
				2: "1.5rem",
				3: "2rem",
				4: "2.5rem",
				5: "3rem",
			},
		},
	},
};
